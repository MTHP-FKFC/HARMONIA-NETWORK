// NetworkManager.cpp - Реализация сетевого менеджера
